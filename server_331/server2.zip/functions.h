#ifndef FUNCTIONS_H
#define FUNCTIONS_H
#include <QString>

//Функция проверки логина/пароля:
QString authorize(std::string login,std::string pass);

#endif
