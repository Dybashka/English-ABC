#ifndef FUNCTIONS_H
#define FUNCTIONS_H
#include <QString>

QString authorize(std::string login,std::string password);

#endif
