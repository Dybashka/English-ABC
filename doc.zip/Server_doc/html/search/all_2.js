var searchData=
[
  ['database_2',['DataBase',['../class_data_base.html',1,'']]],
  ['db_3',['db',['../class_data_base.html#afaefc7539a2749f748e4da979f6d7ce8',1,'DataBase']]]
];
