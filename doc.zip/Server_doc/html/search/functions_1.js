var searchData=
[
  ['closedatabase_12',['closeDataBase',['../class_data_base.html#aa2a38ed1d24cf59d75c0d94edfea0f34',1,'DataBase']]]
];
