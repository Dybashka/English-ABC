var searchData=
[
  ['db_17',['db',['../class_data_base.html#afaefc7539a2749f748e4da979f6d7ce8',1,'DataBase']]]
];
