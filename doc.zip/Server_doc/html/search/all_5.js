var searchData=
[
  ['slotclientdisconnected_6',['slotClientDisconnected',['../class_my_tcp_server.html#a3e040c49dbefd65b9a58ab662fc9f7a2',1,'MyTcpServer']]],
  ['slotnewconnection_7',['slotNewConnection',['../class_my_tcp_server.html#a0ba7316ffe1a26c57fabde9e74b6c8dc',1,'MyTcpServer']]],
  ['slotserverread_8',['slotServerRead',['../class_my_tcp_server.html#ab4a64d2eab985d723090963f5c8a2882',1,'MyTcpServer']]]
];
