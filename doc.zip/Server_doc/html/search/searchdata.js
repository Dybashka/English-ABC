var indexSectionsWithContent =
{
  0: "bcdmos",
  1: "dm",
  2: "bcos",
  3: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Классы",
  2: "Функции",
  3: "Переменные"
};

