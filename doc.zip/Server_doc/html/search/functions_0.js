var searchData=
[
  ['bdquery_11',['bdquery',['../class_data_base.html#a378d18a81780eb446922d328f9acbb6a',1,'DataBase']]]
];
