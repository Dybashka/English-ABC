var searchData=
[
  ['opendatabase_13',['openDataBase',['../class_data_base.html#aff3435cbf802e44b1379888193975136',1,'DataBase']]]
];
