var indexSectionsWithContent =
{
  0: "abclmostu",
  1: "almtu",
  2: "os",
  3: "abclstu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Классы",
  2: "Функции",
  3: "Переменные"
};

