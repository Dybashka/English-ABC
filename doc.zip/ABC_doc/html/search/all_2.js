var searchData=
[
  ['c_6',['C',['../classmenu.html#a0edb46c07ba44b57a6a7aeacb4a97843',1,'menu']]],
  ['ch_7',['ch',['../classmenu.html#a9c270c1bc6387668c4a9c81819619cb3',1,'menu']]],
  ['client_5fsocket_8',['client_socket',['../class_avtoriz.html#afc22696f3ff01543735bf981f624234d',1,'Avtoriz']]]
];
